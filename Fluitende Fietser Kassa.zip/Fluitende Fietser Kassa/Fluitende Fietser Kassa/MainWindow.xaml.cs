﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Threading;
using Microsoft.VisualBasic;


namespace Fluitende_Fietser_Kassa
{
    public partial class MainWindow : Window
    {
        private int ticketNumber = 1;
        private DispatcherTimer timer;
        private int totalTime = 60;
        private int currentTime = 0;
        private bool bikeChosen = false;
        private bool verzekeringChosen = false;
        private bool serviceChosen = false;
        private string currentBike = "";
        private string currentVerzekering = "";
        private string currentService = "";
        private double currentBikePrice = 0.0;
        private double currentVerzekeringPrice = 0.0;
        private double currentServicePrice = 0.0;
        public MainWindow()
        {
            InitializeComponent();
            Aanhangfiets.Click += Button_Click;
            Bakfiets.Click += Button_Click;
            Driewielfiets.Click += Button_Click;
            ElektrischeFiets.Click += Button_Click;
            Kinderfiets.Click += Button_Click;
            Ligfiets.Click += Button_Click;
            OmaFiets.Click += Button_Click;
            RaceFiets.Click += Button_Click;
            SpeedPedelec.Click += Button_Click;
            StadsFiets.Click += Button_Click;
            VouwFiets.Click += Button_Click;
            ZitFiets.Click += Button_Click;
            Beschadigingen.Click += Button2_Click;
            Diefstal.Click += Button2_Click;
            Rechtsbijstand.Click += Button2_Click;
            Ongevallen.Click += Button2_Click;
            Ophaalservice.Click += Button3_Click;
            Regenpak.Click += Button3_Click;
            LunchpakketBasis.Click += Button3_Click;
            LunchpakketUitgebreid.Click += Button3_Click;
            Aanhangfiets.Click += AddAanhangfietsPriceToTotal;
            Bakfiets.Click += AddBakfietsPriceToTotal;
            Driewielfiets.Click += AddDriewielfietsPriceToTotal;
            ElektrischeFiets.Click += AddElektrischeFietsPriceToTotal;
            Kinderfiets.Click += AddKinderfietsPriceToTotal;
            Ligfiets.Click += AddLigfietsPriceToTotal;
            OmaFiets.Click += AddOmaFietsPriceToTotal;
            RaceFiets.Click += AddRaceFietsPriceToTotal;
            SpeedPedelec.Click += AddSpeedPedelecPriceToTotal;
            StadsFiets.Click += AddStadsFietsPriceToTotal;
            VouwFiets.Click += AddVouwFietsPriceToTotal;
            ZitFiets.Click += AddZitFietsPriceToTotal;
            Beschadigingen.Click += AddBeschadigingPriceToTotal;
            Diefstal.Click += AddDiefstalPriceToTotal;
            Rechtsbijstand.Click += AddRechtsbijstandPriceToTotal;
            Ongevallen.Click += AddOngevallenPriceToTotal;
            Ophaalservice.Click += AddOphaalservicePriceToTotal;
            Regenpak.Click += AddRegenpakPriceToTotal;
            LunchpakketBasis.Click += AddLunchpakketBasisPriceToTotal;
            LunchpakketUitgebreid.Click += AddLunchpakketUitgebreidPriceToTotal;
            StartProgressBar();
            KeyDown += MainWindow_KeyDown;

        }



        private void StartProgressBar()
        {

            timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromSeconds(1);
            timer.Tick += Timer_Tick;
            timer.Start();
        }

        private void Window_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            double newWidth = e.NewSize.Width;
            double newHeight = e.NewSize.Height;
            double itemSize = CalculateItemSize(newWidth, newHeight);
            ApplyItemSize(itemSize);
        }

        private double CalculateItemSize(double windowWidth, double windowHeight)
        {

            double itemSize = Math.Min(windowWidth, windowHeight) * 0.026;
            return itemSize;
        }

        private void ApplyItemSize(double itemSize)
        {
            foreach (var item in cbFietsen.Items)
            {
                if (item is ComboBoxItem comboBoxItem)
                {
                    comboBoxItem.FontSize = itemSize;
                }
            }
            foreach (var item in cbFietsVerzekering.Items)
            {
                if (item is ComboBoxItem comboBoxItem)
                {
                    comboBoxItem.FontSize = itemSize;
                }
            }
            foreach (var item in cbServices.Items)
            {
                if (item is ComboBoxItem comboBoxItem)
                {
                    comboBoxItem.FontSize = itemSize;
                }
            }
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            currentTime++;


            progressBar.Value = (double)currentTime / totalTime * 100;
            if (currentTime >= totalTime)
            {
                timer.Stop();

                MessageBoxResult result = MessageBox.Show("De tijd is voorbij. Wilt u meer tijd?", "Tijd verstreken", MessageBoxButton.YesNo, MessageBoxImage.Question);

                if (result == MessageBoxResult.Yes)
                {
                    totalTime += 60;
                    currentTime = 0;
                    timer.Start();
                }
                else
                {

                    MessageBox.Show("Het programma zal nu sluiten...", "", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                    this.Close();
                }
            }
        }


        private void XButton_Click(object sender, RoutedEventArgs e)
        {
            currentTime = 0;
            progressBar.Value = 0;
            this.Close(); this.Close();

        }

        private void HulpButton_Click(object sender, RoutedEventArgs e)
        {

            timer.Stop();
            MessageBox.Show("Welkom bij de hulpsectie\r\n\r\nBedankt voor het gebruik van ons programma. Hier zijn enkele handige tips:\r\n\r\nNavigatie: Gebruik de zoekbalk om snel items te vinden. Typ gewoon het trefwoord en druk op Enter.\r\n\r\nTicketbeheer: Klik op de \"+\" knop om een nieuw ticket toe te voegen. Gebruik de \"x\" knop om een ticket te sluiten.\r\n\r\nFacturering: Bekijk het totaalbedrag onderaan het scherm. U kunt de korting toepassen voordat u betaalt.\r\n\r\nTijdsbeheer: De voortgangsbalk bovenaan toont de resterende tijd. Klik op \"Ok\" om deze tekst te sluiten.\r\n\r\nAfsluiten: Klik op het pictogram \"X\" in de rechterbovenhoek om het programma af te sluiten.", "Hulp", MessageBoxButton.OK, MessageBoxImage.Information);
            currentTime = 0;
            progressBar.Value = 0;
            timer.Start();
        }

        private void WisButton_Click(object sender, RoutedEventArgs e)
        {
            currentTime = 0;
            progressBar.Value = 0;
            bikeChosen = false;
            verzekeringChosen = false;
            serviceChosen = false;
            currentBikePrice = 0.0;
            currentVerzekeringPrice = 0.0;
            currentServicePrice = 0.0;
            KassaBox.Items.Clear();
            HideAllBikes();
            HideInsuranceButtons();
            HideServiceButtons();
            ResetTotalPrice();
            EnableAllButtonsExcept(Allebuttons);

        }
        private void MainWindow_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.F1)
            {
                currentTime = 0;
                progressBar.Value = 0;
                ShowHelpMenu();
            }
        }

        private void ShowHelpMenu()
        {
            timer.Stop();
            MessageBox.Show("Welkom bij de hulpsectie\r\n\r\nBedankt voor het gebruik van ons programma. Hier zijn enkele handige tips:\r\n\r\nNavigatie: Gebruik de zoekbalk om snel items te vinden. Typ gewoon het trefwoord en druk op Enter.\r\n\r\nTicketbeheer: Klik op de \"+\" knop om een nieuw ticket toe te voegen. Gebruik de \"x\" knop om een ticket te sluiten.\r\n\r\nFacturering: Bekijk het totaalbedrag onderaan het scherm. U kunt de korting toepassen voordat u betaalt.\r\n\r\nTijdsbeheer: De voortgangsbalk bovenaan toont de resterende tijd. Klik op \"Ok\" om deze tekst te sluiten.\r\n\r\nAfsluiten: Klik op het pictogram \"X\" in de rechterbovenhoek om het programma af te sluiten.", "Hulp", MessageBoxButton.OK, MessageBoxImage.Information);
            currentTime = 0;
            progressBar.Value = 0;
            timer.Start();
        }

        private void btnCloseTicket_Click(object sender, RoutedEventArgs e)
        {
            if (!bikeChosen)
            {
                MessageBox.Show("Er is geen item geslecteerd.", "Klant Sluiten", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            if (bikeChosen = true && ticketNumber == 1)
            {
                MessageBoxResult result = MessageBox.Show("Weet u zeker dat u alle items wil verwijderen?", "Klant Sluiten", MessageBoxButton.YesNo, MessageBoxImage.Question);

                if (result == MessageBoxResult.Yes)
                {
                    currentTime = 0;
                    progressBar.Value = 0;
                    bikeChosen = false;
                    verzekeringChosen = false;
                    serviceChosen = false;
                    currentBikePrice = 0.0;
                    currentVerzekeringPrice = 0.0;
                    currentServicePrice = 0.0;
                    KassaBox.Items.Clear();
                    HideAllBikes();
                    HideInsuranceButtons();
                    HideServiceButtons();
                    ResetTotalPrice();
                    EnableAllButtonsExcept(Allebuttons);

                }
                else
                {
                    currentTime = 0;
                    progressBar.Value = 0;
                    return;
                }
            }

            if (bikeChosen = true && ticketNumber > 1)
            {
                MessageBoxResult result = MessageBox.Show("Weet u zeker dat u alle items wil verwijderen en een nieuw ticket aanmaken?", "Nieuwe Klant", MessageBoxButton.YesNo, MessageBoxImage.Question);

                if (result == MessageBoxResult.Yes)
                {
                    ticketNumber--;
                    UpdateTicketLabel();
                    currentTime = 0;
                    progressBar.Value = 0;
                    bikeChosen = false;
                    verzekeringChosen = false;
                    serviceChosen = false;
                    currentBikePrice = 0.0;
                    currentVerzekeringPrice = 0.0;
                    currentServicePrice = 0.0;
                    KassaBox.Items.Clear();
                    HideAllBikes();
                    HideInsuranceButtons();
                    HideServiceButtons();
                    ResetTotalPrice();
                    EnableAllButtonsExcept(Allebuttons);

                }
                else
                {
                    currentTime = 0;
                    progressBar.Value = 0;
                    return;
                }
            }
            UpdateTicketLabel();
            currentTime = 0;
            progressBar.Value = 0;
        }

        private void btnNewTicket_Click(object sender, RoutedEventArgs e)
        {
            if (!bikeChosen)
            {
                MessageBox.Show("Er is geen item geslecteerd.", "Nieuwe Klant", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            MessageBoxResult result = MessageBox.Show("Is de bestelling al betaald?", "Nieuwe Klant", MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                ticketNumber++;
                UpdateTicketLabel();
                currentTime = 0;
                progressBar.Value = 0;
                bikeChosen = false;
                verzekeringChosen = false;
                serviceChosen = false;
                currentBikePrice = 0.0;
                currentVerzekeringPrice = 0.0;
                currentServicePrice = 0.0;
                KassaBox.Items.Clear();
                HideAllBikes();
                HideInsuranceButtons();
                HideServiceButtons();
                ResetTotalPrice();
                EnableAllButtonsExcept(Allebuttons);


            }
            else
            {
                currentTime = 0;
                progressBar.Value = 0;
                return;
            }


        }

        private void UpdateTicketLabel()
        {
            TicketLabel.Content = "Klant " + ticketNumber;
            currentTime = 0;
            progressBar.Value = 0;
        }

        private void BtnFietsen_Click(object sender, RoutedEventArgs e)
        {

            currentTime = 0;
            progressBar.Value = 0;
            ShowAllBikes();
            HideInsuranceButtons();
            HideServiceButtons();
        }

        private void BtnFietsVezekering_Click(object sender, RoutedEventArgs e)
        {
            currentTime = 0;
            progressBar.Value = 0;
            if (!bikeChosen)
            {
                MessageBox.Show("Kies eerst een fiets.", "Geen fiets gekozen", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            HideAllBikes();
            HideServiceButtons();
            ShowInsuranceButtons();
        }

        private void BtnServices_Click(object sender, RoutedEventArgs e)
        {
            currentTime = 0;
            progressBar.Value = 0;
            if (!bikeChosen)
            {
                MessageBox.Show("Kies eerst een fiets.", "Geen fiets gekozen", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            if (!verzekeringChosen)
            {
                MessageBox.Show("Kies eerst een verzekering.", "Geen verzekering gekozen", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            HideAllBikes();
            HideInsuranceButtons();
            ShowServiceButtons();
        }

        private void ShowAllBikes()
        {
            Aanhangfiets.Visibility = Visibility.Visible;
            Bakfiets.Visibility = Visibility.Visible;
            Driewielfiets.Visibility = Visibility.Visible;
            ElektrischeFiets.Visibility = Visibility.Visible;
            Kinderfiets.Visibility = Visibility.Visible;
            Ligfiets.Visibility = Visibility.Visible;
            OmaFiets.Visibility = Visibility.Visible;
            RaceFiets.Visibility = Visibility.Visible;
            SpeedPedelec.Visibility = Visibility.Visible;
            StadsFiets.Visibility = Visibility.Visible;
            VouwFiets.Visibility = Visibility.Visible;
            ZitFiets.Visibility = Visibility.Visible;
        }
        private void HideAllBikes()
        {
            Aanhangfiets.Visibility = Visibility.Hidden;
            Bakfiets.Visibility = Visibility.Hidden;
            Driewielfiets.Visibility = Visibility.Hidden;
            ElektrischeFiets.Visibility = Visibility.Hidden;
            Kinderfiets.Visibility = Visibility.Hidden;
            Ligfiets.Visibility = Visibility.Hidden;
            OmaFiets.Visibility = Visibility.Hidden;
            RaceFiets.Visibility = Visibility.Hidden;
            SpeedPedelec.Visibility = Visibility.Hidden;
            StadsFiets.Visibility = Visibility.Hidden;
            VouwFiets.Visibility = Visibility.Hidden;
            ZitFiets.Visibility = Visibility.Hidden;
        }

        private void ShowInsuranceButtons()
        {
            Beschadigingen.Visibility = Visibility.Visible;
            Diefstal.Visibility = Visibility.Visible;
            Rechtsbijstand.Visibility = Visibility.Visible;
            Ongevallen.Visibility = Visibility.Visible;
        }

        private void HideInsuranceButtons()
        {
            Beschadigingen.Visibility = Visibility.Hidden;
            Diefstal.Visibility = Visibility.Hidden;
            Rechtsbijstand.Visibility = Visibility.Hidden;
            Ongevallen.Visibility = Visibility.Hidden;
        }

        private void ShowServiceButtons()
        {
            Ophaalservice.Visibility = Visibility.Visible;
            Regenpak.Visibility = Visibility.Visible;
            LunchpakketBasis.Visibility = Visibility.Visible;
            LunchpakketUitgebreid.Visibility = Visibility.Visible;
        }

        private void HideServiceButtons()
        {
            Ophaalservice.Visibility = Visibility.Hidden;
            Regenpak.Visibility = Visibility.Hidden;
            LunchpakketBasis.Visibility = Visibility.Hidden;
            LunchpakketUitgebreid.Visibility = Visibility.Hidden;
        }


        private void Button_Click(object sender, RoutedEventArgs e)
        {
            currentTime = 0;
            progressBar.Value = 0;
            Button clickedButton = sender as Button;
            if (clickedButton != null)
            {
                if (!bikeChosen)
                {
                    KassaBox.Items.Add(clickedButton.Content);
                    bikeChosen = true;
                    currentBike = clickedButton.Content.ToString();

                }
                else
                {
                    KassaBox.Items.RemoveAt(0);
                    KassaBox.Items.Insert(0, clickedButton.Content);
                    currentBike = clickedButton.Content.ToString();

                }
            }
        }

        private void Button2_Click(object sender, RoutedEventArgs e)
        {
            currentTime = 0;
            progressBar.Value = 0;
            Button clickedButton = sender as Button;
            if (clickedButton != null)
            {
                if (!verzekeringChosen)
                {
                    KassaBox.Items.Add(clickedButton.Content);
                    verzekeringChosen = true;
                    currentVerzekering = clickedButton.Content.ToString();


                }
                else
                {
                    KassaBox.Items.RemoveAt(1);
                    KassaBox.Items.Insert(1, clickedButton.Content);
                    currentVerzekering = clickedButton.Content.ToString();

                }
            }
        }

        private void Button3_Click(object sender, RoutedEventArgs e)
        {
            currentTime = 0;
            progressBar.Value = 0;
            Button clickedButton = sender as Button;
            if (clickedButton != null)
            {
                if (!serviceChosen)
                {
                    KassaBox.Items.Add(clickedButton.Content);
                    serviceChosen = true;
                    currentService = clickedButton.Content.ToString();
                }
                else
                {
                    KassaBox.Items.RemoveAt(2);
                    KassaBox.Items.Insert(2, clickedButton.Content);
                    currentService = clickedButton.Content.ToString();
                }

            }
        }


        private void ResetTotalPrice()
        {
            lbTotaalGeld.Content = "€ 0,00";
            currentBikePrice = 0.0;
            currentVerzekeringPrice = 0.0;
        }

        private void AddPriceToTotal(double price)
        {
            double currentTotal = Convert.ToDouble(lbTotaalGeld.Content.ToString().Replace("€", "").Trim());
            currentTotal += price;

            lbTotaalGeld.Content = "€ " + currentTotal.ToString("0.00");
        }
        private void AddBikePriceToTotal(double price)
        {
            double previousBikePrice = currentBikePrice;
            currentBikePrice = price;
            AddPriceToTotal(-previousBikePrice);
            AddPriceToTotal(currentBikePrice);
        }


        private void AddVerzekeringPriceToTotal(double price)
        {
            double previousVerzekeringPrice = currentVerzekeringPrice;
            currentVerzekeringPrice = price;

            AddPriceToTotal(currentVerzekeringPrice - previousVerzekeringPrice);
        }

        private void AddServicePriceToTotal(double price)
        {
            double previousServicePrice = currentServicePrice;
            currentServicePrice = price;

            AddPriceToTotal(currentServicePrice - previousServicePrice);
        }



        private void AddAanhangfietsPriceToTotal(object sender, RoutedEventArgs e)
        {
            double aanhangfietsPrice = 20.00;
            AddBikePriceToTotal(aanhangfietsPrice);

            Aanhangfiets.IsEnabled = false;
            EnableAllButtonsExcept(Aanhangfiets);
        }

        private void AddBakfietsPriceToTotal(object sender, RoutedEventArgs e)
        {
            double bakfietsPrice = 35.00;
            AddBikePriceToTotal(bakfietsPrice);

            Bakfiets.IsEnabled = false;
            EnableAllButtonsExcept(Bakfiets);
        }

        private void AddDriewielfietsPriceToTotal(object sender, RoutedEventArgs e)
        {
            double driewielfietsPrice = 30.00;
            AddBikePriceToTotal(driewielfietsPrice);

            Driewielfiets.IsEnabled = false;
            EnableAllButtonsExcept(Driewielfiets);
        }

        private void AddElektrischeFietsPriceToTotal(object sender, RoutedEventArgs e)
        {
            double elektrischeFietsPrice = 30.00;
            AddBikePriceToTotal(elektrischeFietsPrice);

            ElektrischeFiets.IsEnabled = false;
            EnableAllButtonsExcept(ElektrischeFiets);
        }

        private void AddKinderfietsPriceToTotal(object sender, RoutedEventArgs e)
        {
            double kinderfietsPrice = 15.00;
            AddBikePriceToTotal(kinderfietsPrice);

            Kinderfiets.IsEnabled = false;
            EnableAllButtonsExcept(Kinderfiets);
        }

        private void AddLigfietsPriceToTotal(object sender, RoutedEventArgs e)
        {
            double ligfietsPrice = 45.00;
            AddBikePriceToTotal(ligfietsPrice);

            Ligfiets.IsEnabled = false;
            EnableAllButtonsExcept(Ligfiets);
        }

        private void AddOmaFietsPriceToTotal(object sender, RoutedEventArgs e)
        {
            double omaFietsPrice = 12.50;
            AddBikePriceToTotal(omaFietsPrice);

            OmaFiets.IsEnabled = false;
            EnableAllButtonsExcept(OmaFiets);
        }

        private void AddRaceFietsPriceToTotal(object sender, RoutedEventArgs e)
        {
            double raceFietsPrice = 15.00;
            AddBikePriceToTotal(raceFietsPrice);

            RaceFiets.IsEnabled = false;
            EnableAllButtonsExcept(RaceFiets);
        }

        private void AddSpeedPedelecPriceToTotal(object sender, RoutedEventArgs e)
        {
            double speedPedelecPrice = 15.00;
            AddBikePriceToTotal(speedPedelecPrice);

            SpeedPedelec.IsEnabled = false;
            EnableAllButtonsExcept(SpeedPedelec);
        }

        private void AddStadsFietsPriceToTotal(object sender, RoutedEventArgs e)
        {
            double stadsFietsPrice = 12.50;
            AddBikePriceToTotal(stadsFietsPrice);

            StadsFiets.IsEnabled = false;
            EnableAllButtonsExcept(StadsFiets);
        }

        private void AddVouwFietsPriceToTotal(object sender, RoutedEventArgs e)
        {
            double vouwFietsPrice = 10.00;
            AddBikePriceToTotal(vouwFietsPrice);

            VouwFiets.IsEnabled = false;
            EnableAllButtonsExcept(VouwFiets);
        }

        private void AddZitFietsPriceToTotal(object sender, RoutedEventArgs e)
        {
            double zitFietsPrice = 15.00;
            AddBikePriceToTotal(zitFietsPrice);

            ZitFiets.IsEnabled = false;
            EnableAllButtonsExcept(ZitFiets);
        }

        private void AddBeschadigingPriceToTotal(object sender, RoutedEventArgs e)
        {
            double beschadigingPrice = 5.00;
            AddVerzekeringPriceToTotal(beschadigingPrice);

            Beschadigingen.IsEnabled = false;
            EnableAllButtonsExcept(Beschadigingen);
        }

        private void AddDiefstalPriceToTotal(object sender, RoutedEventArgs e)
        {
            double diefstalPrice = 10.00;
            AddVerzekeringPriceToTotal(diefstalPrice);

            Diefstal.IsEnabled = false;
            EnableAllButtonsExcept(Diefstal);
        }

        private void AddRechtsbijstandPriceToTotal(object sender, RoutedEventArgs e)
        {
            double rechtsbijstandPrice = 5.00;
            AddVerzekeringPriceToTotal(rechtsbijstandPrice);

            Rechtsbijstand.IsEnabled = false;
            EnableAllButtonsExcept(Rechtsbijstand);
        }

        private void AddOngevallenPriceToTotal(object sender, RoutedEventArgs e)
        {
            double ongevallenPrice = 2.50;
            AddVerzekeringPriceToTotal(ongevallenPrice);

            Ongevallen.IsEnabled = false;
            EnableAllButtonsExcept(Ongevallen);
        }

        private void AddOphaalservicePriceToTotal(object sender, RoutedEventArgs e)
        {
            double ophaalservicePrice = 15.00;
            AddServicePriceToTotal(ophaalservicePrice);

            Ophaalservice.IsEnabled = false;
            EnableAllButtonsExcept(Ophaalservice);
        }

        private void AddRegenpakPriceToTotal(object sender, RoutedEventArgs e)
        {
            double regenpakPrice = 10.00;
            AddServicePriceToTotal(regenpakPrice);

            Regenpak.IsEnabled = false;
            EnableAllButtonsExcept(Regenpak);
        }

        private void AddLunchpakketBasisPriceToTotal(object sender, RoutedEventArgs e)
        {
            double lunchpakketBasisPrice = 12.50;
            AddServicePriceToTotal(lunchpakketBasisPrice);

            LunchpakketBasis.IsEnabled = false;
            EnableAllButtonsExcept(LunchpakketBasis);
        }

        private void AddLunchpakketUitgebreidPriceToTotal(object sender, RoutedEventArgs e)
        {
            double lunchpakketUitgebreidPrice = 20.00;
            AddServicePriceToTotal(lunchpakketUitgebreidPrice);

            LunchpakketUitgebreid.IsEnabled = false;
            EnableAllButtonsExcept(LunchpakketUitgebreid);
        }

        private void EnableAllButtonsExcept(Button exceptButton)
        {
            List<Button> bikeButtons = new List<Button>
    {
        Aanhangfiets, Bakfiets, Driewielfiets, ElektrischeFiets, Kinderfiets,
        Ligfiets, OmaFiets, RaceFiets, SpeedPedelec, StadsFiets, VouwFiets, ZitFiets, Beschadigingen, Diefstal, Rechtsbijstand, Ongevallen,
        Allebuttons, Ophaalservice, Regenpak, LunchpakketBasis, LunchpakketUitgebreid

    };

            foreach (var button in bikeButtons)
            {
                if (button != exceptButton)
                {
                    button.IsEnabled = true;
                }
                else
                {
                    button.IsEnabled = false;
                }
            }
        }
        private void KortingButton_Click(object sender, RoutedEventArgs e)
        {
            currentTime = 0;
            progressBar.Value = 0;
            Rekenmachine rekenmachineWindow = new Rekenmachine();
            rekenmachineWindow.Show();
        }
        private void BetaalButton_Click(object sender, RoutedEventArgs e)
        {
            currentTime = 0;
            progressBar.Value = 0;
            if (KassaBox.Items.Count == 0)
            {
                MessageBox.Show("Voeg eerst items toe voordat je kunt betalen.", "Geen items toegevoegd", MessageBoxButton.OK, MessageBoxImage.Information);
                return; // Voorkom verdere verwerking van de betaling
            }
            InputDialog inputDialog = new InputDialog();
            if (inputDialog.ShowDialog() == true)
            {
                if (double.TryParse(inputDialog.InputText, out double factor))
                {
                    if (double.TryParse(lbTotaalGeld.Content.ToString().Replace("€", "").Trim(), out double totalPrice))
                    {
                        double newTotalPrice = totalPrice * factor;

                        MessageBox.Show($"Deze bestelling kost €{newTotalPrice:F2} en de klant heeft voor {factor} dag(en) gekozen.", "Afrekenen", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                    else
                    {
                        MessageBox.Show("Fout bij het ophalen van de totaalprijs.", "", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                }
                else
                {
                    MessageBox.Show("Ongeldige invoer. Voer alstublieft een geldig nummer in.", "Ongeldige Invoer", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
        }
    }
}


